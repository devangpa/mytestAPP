const Application = require("../models/applicationModel");
const Job = require("../models/jobModel");

exports.appliedonjob = async (req, res, next) => {
  try {
    let createApplication = await Application.create(req.body);
    let UpdateJob = await Job.update(
      { _id: req.body.jobId },
      { $push: { Applications: createApplication._id } }
    );

    res
      .status(200)
      .json({ Message: "Created Sucessfully", data: createApplication });
  } catch (e) {
    res.status(400).json({ Message: "Not able to create", data: e });
  }
};



exports.getmyappliedjob=async(req,res,next)=>{
  try{
    console.log(req.body)
    let getmyappliedJob = await Application.find({Applicantemail:req.body.Applicantid}).populate('jobId')
    res.status(200).json({ Message: "Created Sucessfully", data: getmyappliedJob})
  }catch(e){
    res.status(400).json({ Message: "Not able to Get", data: e });
  }
}