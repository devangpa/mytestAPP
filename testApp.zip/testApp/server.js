const mongoose = require("mongoose");
const app = require("./app");

mongoose
  .connect(
    "mongodb://devangp:devangp8688@ds117145.mlab.com:17145/trangulation",
    {
      useNewUrlParser: true,
      useCreateIndex: true,
      useFindAndModify: false,
    }
  )
  .then(() => console.log("Database Connected Sucessfull!!"));
const port = 5000;

const server = app.listen(port, () => {
  console.log(`App running on port ${port}...`);
});
