import React, { Component } from "react";

import "./App.css";
import { GoogleLogin, GoogleLogout } from "react-google-login";
import axios from "axios";
import Candidate from "./Candidate";
import Recruiter from "./Recruiter";

const CLIENT_ID =
  "573215203697-dbc4o7au0dhh0vbvdsietu4rh6iebgc9.apps.googleusercontent.com";

class App extends Component {
  constructor(props) {
    super(props);

    this.state = {
      isLogined: false,
      email: "",
      name: "",
      photo: "",
      showData: false,
      getRole: false,
      errorMessage: "",
      showlanding: true,
      userrole: "",
      passingdata: "",
    };
  }

  //signup Middleware
  signup = async (res) => {
    console.log(res);
    this.setState({ email: res.profileObj.email });
    this.setState({ name: res.profileObj.name });
    this.setState({ showData: true });
    let sendrequest = {
      name: res.profileObj.name,
      email: res.profileObj.email,
      mobile: 999999999,
      photo: res.profileObj.imageUrl,
    };
    let sendreq = await axios.post(
      "http://localhost:5000/api/v1/signup",
      sendrequest
    );

    if (sendreq.status === 201) {
      await this.setState({ getRole: true });
    } else if (sendreq.status === 400) {
      await this.setState({ errorMessage: "Somthing Goes wrong" });
      console.log(this.state.errorMessage);
    } else {
      console.log("Somthing Went wrong");
    }
  };

  //Handal Signin
  signin = async (res) => {
    console.log(res);
    this.setState({
      email: res.profileObj.email,
      name: res.profileObj.name,
      photo: res.profileObj.imageUrl,
    });
    
    let signin = { email: res.profileObj.email };
    let login = await axios.post("http://localhost:5000/api/v1/login", signin);

    console.log(login.data.data);
    this.setState({ userrole: login.data.data });
    if (login.status === 200) {
      this.setState({ showlanding: false });
      let passingcomponantdata = { email: res.profileObj.email };
      let passingstr = JSON.stringify(passingcomponantdata);
      this.setState({ passingdata: passingstr });
    } else {
      this.setState({ showlanding: false });
    }
  };

  checkrole = async (e) => {
    e.preventDefault();
    const value = e.target.value;
    let updateData = { email: this.state.email, role: value };
    let updaterole = await axios.patch(
      "http://localhost:5000/api/v1/updateme",
      updateData
    );
    if (updaterole.status === 200) {
      let role = updaterole.data.data;
      this.setState({ userrole: role, getRole: false, showlanding: false });
      console.log(role);
    } else {
      console.log("Somthing Goes Wrong");
    }
  };

  handleLoginFailure = async (res) => {
    console.log(res);
  };

  logout = async (e) => {
    console.log("++++++++++++++")

    this.setState({ showlanding: true, email: "", name: "" });
  };

  render() {
    return (
      <div className="App">
        {this.state.showlanding ? (
          <div class="container">
            <div class="row">
              <div class="col-sm"></div>
              <div class="col-sm">
                <div
                  class="card"
                  style={{ alignContent: "center", marginTop: "50%" }}
                >
                  <div class="card-body">
                    <h5 class="card-title">
                      <b>Welcome To Test App</b>
                    </h5>
                    <div class="row">
                      <div class="col">
                        <GoogleLogin
                          clientId={CLIENT_ID}
                          buttonText="Signup"
                          onSuccess={this.signup}
                          onFailure={this.handleLoginFailure}
                          cookiePolicy={"single_host_origin"}
                          responseType="code,token"
                        />
                      </div>
                      <div class="col">
                        <GoogleLogin
                          clientId={CLIENT_ID}
                          buttonText="signin"
                          onSuccess={this.signin}
                          onFailure={this.handleLoginFailure}
                          cookiePolicy={"single_host_origin"}
                          responseType="code,token"
                        />
                      </div>
                    </div>
                    <hr />
                    {this.state.getRole ? (
                      <div>
                        <div>
                          <h6 style={{ color: "green" }}>
                            <b>SuccessFullly Signup Who You Are?</b>
                          </h6>
                        </div>
                        <div class="row" style={{ textAlign: "center" }}>
                          <div class="col">
                            <button
                              type="button"
                              class="btn btn-primary"
                              value="candidate"
                              onClick={this.checkrole}
                              clickedlog={this.logout}
                            >
                              Candidate
                            </button>
                          </div>
                          <div class="col">
                            <button
                              type="button"
                              class="btn btn-primary"
                              value="recruiter"
                              onClick={this.checkrole}
                              clickedlog={this.logout}
                            >
                              Recruiter
                            </button>
                          </div>
                        </div>
                      </div>
                    ) : null}
                  </div>
                </div>
              </div>
              <div class="col-sm"></div>
            </div>
          </div>
        ) : (
          <div>
            {this.state.userrole === "candidate" ? (
              <Candidate
                useridentity={this.state.passingdata}
                name={this.state.name}
                photo={this.state.photo}
                clickMe={this.logout}
                email={this.state.email}
                role={this.state.userrole}
              />
            ) : (
              <Recruiter
                useridentity={this.state.passingdata}
                name={this.state.name}
                photo={this.state.photo}
                clickMe={this.logout}
                email={this.state.email}
                role={this.state.userrole}
              />
            )}
          </div>
        )}
      </div>
    );
  }
}

export default App;
