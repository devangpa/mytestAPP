import React, { useState, useEffect } from "react";
import axios from 'axios'
const Recruiter = (props) => {
  const [model, setmodel] = useState(true);

  const [jobtitle, setjobtitle] = useState("");
  const [jobdescription, setjobdescription] = useState("");
  const [area, setarea] = useState("");
  const [city, setcity] = useState("");
  const [state, setstate] = useState("");
  const [country, setcountry] = useState("");
  const [company, setcompany] = useState("");
  const [position_no, setposition_no] = useState(0);
  const [minex, setminex] = useState(0);
  const [maxex, setmaxex] = useState(0);
  const [minsal, setminsal] = useState(0);
  const [maxsal, setmaxsal] = useState(0);
  const [respospost,setrespospost]=useState(false)
  
  


  //JObs States 
  const [getjobs,setjobs]=useState([])

  const handleSubmit = async (e) => {
    e.preventDefault();
   let createdata = {
   
      jobtitle:jobtitle,
      jobdescription:jobdescription,
      area:area,
      city:city,
      state:state,
      country:country,
      company:company,
      position_no:position_no,
      minex:minex,
      maxex:maxex,
      minsal:minsal,
      Jobcreator:props.email,
      maxsal:maxsal
    }
    let senddata = await axios.post('http://localhost:5000/api/v1/job',createdata)
    if(senddata.status===200){
      setrespospost(true)
    }
};



const getmyjob =async()=>{
  

  let getmyjobs = await axios("http://localhost:5000/api/v1/myjobs",{Jobcreator:props.email})
  console.log(getmyjobs)

  //Get My created JObs
  setjobs(getmyjobs.data.data)
  setmodel(false)

}

  return (
    <div>
      <nav class="navbar navbar-dark bg-dark">
        <a class="navbar-brand" href="#">
          <b>Test App</b>
        </a>

        <button type="button" class="btn btn-light" onClick={()=>{props.clickMe()}}>
          Logout
        </button>
      </nav>
      {
        respospost===true?(<h6>Added Sucessfull</h6>):null
      }
      <div class="container" style={{ margintop: "20px" }}>
        <div class="row">
          <div class="col-sm">
            {" "}
            <h6>
              <b>
                Hi {props.name}({props.role})
              </b>
            </h6>
            <hr />
            <img src={props.photo} alt="User Image" />
            <hr />
            <button
              type="button"
              class="btn btn-primary"
              onClick={() => {
                setmodel(true);
              }}
            >
              Add Job
            </button>
            <hr />
            <button type="button" class="btn btn-primary" onClick={getmyjob} >
              view My Created Job
            </button>
          </div>
          <div class="col-md">
          {model ? (<form onSubmit={handleSubmit}>
              <div class="form-group">
                <label for="exampleFormControlInput1">Job Title</label>
                <input
                  type="text"
                  class="form-control"
                  placeholder="Job Title"
                  onChange={(e) => setjobtitle(e.target.value)}
                />
              </div>
              <div class="form-group">
                <input
                  type="text"
                  class="form-control"
                  placeholder="Job Description"
                  onChange={(e) => setjobdescription(e.target.value)}
                />
              </div>
              <div class="form-group">
                <input
                  type="text"
                  class="form-control"
                  placeholder=" Area"
                  onChange={(e) => setarea(e.target.value)}
                />
              </div>
              <div class="form-group">
                <input
                  type="text"
                  class="form-control"
                  placeholder=" city"
                  onChange={(e) => setcity(e.target.value)}
                />
              </div>
              <div class="form-group">
                <input
                  type="text"
                  class="form-control"
                  placeholder=" state"
                  onChange={(e) => setstate(e.target.value)}
                />
              </div>
              <div class="form-group">
                <input
                  type="text"
                  class="form-control"
                  placeholder=" country"
                  onChange={(e) => setcountry(e.target.value)}
                />
              </div>
              <div class="form-group">
                <input
                  type="text"
                  class="form-control"
                  placeholder=" company"
                  onChange={(e) => setcompany(e.target.value)}
                />
              </div>
              <div class="form-group">
                <input
                  type="number"
                  class="form-control"
                  placeholder=" Position No"
                  onChange={(e) => setposition_no(e.target.value)}
                />
              </div>
              <div class="form-group">
                <input
                  type="number"
                  class="form-control"
                  placeholder=" Minimum Experience"
                  onChange={(e) => setminex(e.target.value)}
                />
              </div>
              <div class="form-group">
                <input
                  type="number"
                  class="form-control"
                  placeholder=" Maxmum Experience"
                  onChange={(e) => setmaxex(e.target.value)}
                />
              </div>
              <div class="form-group">
                <input
                  type="number"
                  class="form-control"
                  placeholder=" Min Salary"
                  onChange={(e) => setminsal(e.target.value)}
                />
              </div>
              <div class="form-group">
                <input
                  type="number"
                  class="form-control"
                  placeholder=" Max Salary"
                  onChange={(e) => setmaxsal(e.target.value)}
                />
              </div>

              <button type="submit" class="btn btn-primary">
                Submit
              </button>
            </form>):(<h6>My created JObs</h6>)}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Recruiter;
