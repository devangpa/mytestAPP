import React, { useState, useEffect } from "react";
import axios from 'axios'
const Candidate = (props) => {
  const [model, setmodel] = useState(true);
  const [jobs,setjobs]=useState([])


  
  let myjobs =async()=>{
    setmodel(true)
    console.log("+++++++++")
    let getalljobs = await axios.get("http://localhost:5000/api/v1/jobs")
    console.log(getalljobs.data.data)
    setjobs(getalljobs.data.data)
    
  }
  let getmyappliedjobs =async()=>{
    setmodel(false)
    console.log("-------------")
    let myappliedjobs = await axios.get("http://localhost:5000/api/v1/getmyappliedjob",{Applicantemail:props.email})
    console.log(myappliedjobs.data.data)
  }
  // useEffect(() => {
  //   let getalljobs =  axios.get("http://localhost:5000/api/v1/jobs")
  //   console.log(getalljobs.data.data)
  //   setjobs(getalljobs.data.data)
  // });
  return (
    <div>
      <nav class="navbar navbar-dark bg-dark">
        <a class="navbar-brand" href="#">
          <b>Test App</b>
        </a>

        <button type="button" class="btn btn-light" onClick={()=>{props.clickMe()}}>
          Logout
        </button>
      </nav>
      <div class="container" style={{ margintop: "20px" }}>
        <div class="row">
          <div class="col-sm">
            {" "}
            <h6>
              <b>
                Hi {props.name}({props.role})
              </b>
            </h6>
            <hr />
            <img src={props.photo} alt="User Image" />
            <hr/>
            <button
              type="button"
              class="btn btn-primary"
              onClick={myjobs}
            >
              Jobs
            </button>
            <hr/>
            <button
              type="button"
              class="btn btn-primary"
              onClick={getmyappliedjobs}
            >
              My Applied Jobs
            </button>

          </div>
          <div class="col-md">

          {
            model?(<div><h1>Jobs</h1></div>):(<h1> My Applied jobs</h1>)
          }

          </div>
         
        </div>
      </div>
    </div>
  );
};

export default Candidate;
