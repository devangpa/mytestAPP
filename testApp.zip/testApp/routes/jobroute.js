const express = require("express");
const jobController = require("./../controllers/jobcontroller");
const router = express.Router();

//Authentication routes
router.post("/job", jobController.createJob);
router.get("/jobs", jobController.Jobs);
router.get('/myjobs',jobController.findMycreatedJobs)

module.exports = router;
