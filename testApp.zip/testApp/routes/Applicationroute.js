const express = require("express");
const applicationController = require("./../controllers/applicationController");
const { route } = require("./jobroute");
const router = express.Router();

//Authentication routes
router.post("/application", applicationController.appliedonjob);
router.get('/getmyappliedjob',applicationController.getmyappliedjob)

module.exports = router;
